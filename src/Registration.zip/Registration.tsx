import React, { useState } from 'react';
import {
  Box,
  Button,
  Checkbox,
  FormControl,
  FormControlLabel,
  FormLabel,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
  Grid,
} from '@mui/material';
import { SelectChangeEvent } from '@mui/material/Select';
import './Registration.css';

const departments = [
  'HR',
  'Finance',
  'IT',
  'Marketing',
  'Research',
  // Add more departments as needed
];

const RegistrationForm: React.FC = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    employeeID: '',
    department: '',
    position: '',
    email: '',
    phone: '',
    role: '',
    supervisorApproval: false,
    registrationDate: new Date().toISOString().split('T')[0],
    username: '',
    password: '',
    confirmPassword: '',
    terms: false,
    notifications: false,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement> | SelectChangeEvent<string>) => {
    const { name, value, type, checked } = e.target as HTMLInputElement;
    if (type === 'checkbox') {
      setFormData((prev) => ({
        ...prev,
        [name]: checked,
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  const handleSelectChange = (e: SelectChangeEvent<string>) => {
    setFormData((prev) => ({
      ...prev,
      department: e.target.value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Implement your form submission logic here
    console.log('Form submitted:', formData);
  };

  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ maxWidth: 500, margin: 'auto', padding: 3, backgroundColor: 'white', borderRadius: 2, boxShadow: 2 }}>
      <Typography variant="h4" component="h2" textAlign="center" gutterBottom>
        Registration Form
      </Typography>
      
      <Grid container spacing={2}>
        <Grid item xs={6}>
          <TextField
            label="Full Name"
            name="fullName"
            value={formData.fullName}
            onChange={handleChange}
            margin="normal"
            required
            fullWidth
            size='small'
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            label="Employee ID"
            name="employeeID"
            value={formData.employeeID}
            onChange={handleChange}
            margin="normal"
            required
            fullWidth
            size='small'
          />
        </Grid>

        <Grid item xs={6}>
          <FormControl fullWidth margin="normal" required size='small'>
            <InputLabel>Department</InputLabel>
            <Select
              name="department"
              value={formData.department}
              onChange={handleSelectChange}
            >
              <MenuItem value="" disabled>Select your department</MenuItem>
              {departments.map((dept) => (
                <MenuItem key={dept} value={dept}>{dept}</MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>

        <Grid item xs={6}>
          <TextField
            label="Position/Title"
            name="position"
            value={formData.position}
            onChange={handleChange}
            margin="normal"
            required
            fullWidth
            size='small'
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            label="Email Address"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            margin="normal"
            required
            fullWidth
            size='small'
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            label="Phone Number"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            margin="normal"
            required
            fullWidth
            size='small'
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            label="Role"
            name="role"
            value={formData.role}
            margin="normal"
            onChange={handleChange}
            fullWidth
            size='small'
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            label="Date of Registration"
            name="registrationDate"
            type="date"
            value={formData.registrationDate}
            margin="normal"
            fullWidth
            size='small'
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            label="Username"
            name="username"
            value={formData.username}
            onChange={handleChange}
            margin="normal"
            required
            fullWidth
            size='small'
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            label="Password"
            name="password"
            type="password"
            value={formData.password}
            onChange={handleChange}
            margin="normal"
            required
            fullWidth
            size='small'
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            label="Confirm Password"
            name="confirmPassword"
            type="password"
            value={formData.confirmPassword}
            onChange={handleChange}
            margin="normal"
            required
            fullWidth
            size='small'
          />
        </Grid>

        <Grid item xs={12}>
          <FormControlLabel
            control={
              <Checkbox
                name="supervisorApproval"
                checked={formData.supervisorApproval}
                onChange={handleChange}
              />
            }
            label="Check if approved (or upload authorization letter)"
          />
          <TextField
            type="file"
            name="authorizationLetter"
            margin="normal"
            fullWidth
            size='small'
          />
        </Grid>

        <Grid item xs={6}>
          <FormControlLabel
            control={
              <Checkbox
                name="terms"
                checked={formData.terms}
                onChange={handleChange}
                required
              />
            }
            label="I agree to the Terms and Conditions"
          />
        </Grid>

        <Grid item xs={6}>
          <FormControlLabel
            control={
              <Checkbox
                name="notifications"
                checked={formData.notifications}
                onChange={handleChange}
              />
            }
            label="I consent to receive notifications"
          />
        </Grid>

        <Grid item xs={6}>
          <Button variant="contained" color="primary" type="submit" fullWidth>
            Register
          </Button>
        </Grid>
      </Grid>
    </Box>
  );
};

export default RegistrationForm;

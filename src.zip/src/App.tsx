import './App.css';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// import DIReview from './DIReview/LodgeRequest';
import Dashboard from './ReviewDashboard/Dashboard';
import CommitteeReview from './DIReview/Example';

function App() {
  return (
   <>
   <Router>
        <Routes>
          <Route path="/" element={<Dashboard/>}/>
          <Route path="/asdf" element={<CommitteeReview/>}/>

</Routes>
</Router>
   </>
  );
}

export default App;
